#!/usr/bin/env python3
"""Compuerta previa de un paquete exacto: derechos, firmas, pruebas y contenido.

No publica. La política y las llaves de confianza deben estar bajo revisión protegida.
Una firma válida no sustituye el dictamen jurídico: prueba quién aprobó sus bytes.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from artifact_inventory import archive_files, digest

RIGHTS = {
    "models",
    "datasets",
    "fonts",
    "sdk_contracts",
    "native_binaries",
    "own_ip",
    "third_party_notices",
    "transitive_dependencies",
}
CHECKS = {
    "backend",
    "web",
    "sdks",
    "postgresql_isolation",
    "license_integrity",
    "sbom_schema",
    "artifact_content",
    "vulnerability_scan",
    "secret_scan",
}
RESOLVED = {"RESOLVED", "RESOLVED_WITH_OBLIGATIONS", "NOT_APPLICABLE_WITH_EVIDENCE"}


def confined(root: Path, value: str) -> Path:
    if not isinstance(value, str) or not value or Path(value).is_absolute():
        raise ValueError("Ruta de evidencia inválida")
    path = root / value
    if (
        not path.resolve().is_relative_to(root.resolve())
        or not path.is_file()
        or path.is_symlink()
    ):
        raise ValueError("Evidencia ausente o fuera del expediente")
    return path


def evidence(root: Path, row: dict) -> Path:
    path = confined(root, row.get("path"))
    if digest(path) != row.get("sha256"):
        raise ValueError("Hash de evidencia diferente: " + row["path"])
    return path


def verify_signatures(root: Path, manifest: dict, trust: dict) -> None:
    body = {key: value for key, value in manifest.items() if key != "signatures"}
    signed = json.dumps(
        body, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode()
    keys = trust.get("keys", [])
    roles = {}
    with tempfile.TemporaryDirectory(prefix="ivp-signature-") as directory:
        message = Path(directory) / "message.json"
        message.write_bytes(signed)
        for signature in manifest.get("signatures", []):
            matches = [
                key for key in keys if key.get("key_id") == signature.get("key_id")
            ]
            if len(matches) != 1:
                raise ValueError("Firmante no autorizado")
            key = matches[0]
            public = evidence(root, key)
            if key.get("role") not in {"legal", "release"} or not key.get("reviewer"):
                raise ValueError("Rol o revisor de firma inválido")
            detached = Path(directory) / "signature.bin"
            detached.write_bytes(
                base64.b64decode(signature["signature"], validate=True)
            )
            result = subprocess.run(
                [
                    "openssl",
                    "dgst",
                    "-sha256",
                    "-verify",
                    str(public),
                    "-signature",
                    str(detached),
                    str(message),
                ],
                capture_output=True,
                timeout=15,
                check=False,
            )
            if result.returncode != 0:
                raise ValueError("Firma criptográfica inválida")
            if key["role"] in roles:
                raise ValueError("Rol de aprobación duplicado")
            roles[key["role"]] = key["reviewer"]
    if set(roles) != {"legal", "release"} or len(set(roles.values())) != 2:
        raise ValueError(
            "Se requieren dos revisores independientes: jurídico y release"
        )


def verify_artifact(root: Path, artifact: dict) -> None:
    path = evidence(root, artifact)
    rows = archive_files(path)
    expected = {row["path"]: row["sha256"] for row in rows}
    cdx = json.loads(evidence(root, artifact["cyclonedx"]).read_text())
    spdx = json.loads(evidence(root, artifact["spdx"]).read_text())
    if cdx.get("specVersion") != "1.6" or spdx.get("spdxVersion") != "SPDX-2.3":
        raise ValueError("Formato SBOM inesperado")
    cdx_digest = cdx["metadata"]["component"]["hashes"]
    spdx_digest = spdx["packages"][0]["checksums"]
    if {"alg": "SHA-256", "content": artifact["sha256"]} not in cdx_digest or {
        "algorithm": "SHA256",
        "checksumValue": artifact["sha256"],
    } not in spdx_digest:
        raise ValueError("SBOM no vinculado al artefacto")
    cdx_files = {
        c["name"]: next(h["content"] for h in c["hashes"] if h["alg"] == "SHA-256")
        for c in cdx["components"]
        if c["type"] == "file"
    }
    spdx_files = {
        f["fileName"]: next(
            h["checksumValue"] for h in f["checksums"] if h["algorithm"] == "SHA256"
        )
        for f in spdx["files"]
    }
    if (
        cdx_files != expected
        or spdx_files != expected
        or len(cdx_files) != len(cdx["components"])
        or len(spdx_files) != len(spdx["files"])
    ):
        raise ValueError("Contenido desconocido, omitido o duplicado en SBOM")
    for component in cdx["components"]:
        states = [
            p["value"]
            for p in component.get("properties", [])
            if p.get("name") == "ivp:status"
        ]
        if len(states) != 1 or states[0] not in {
            "APPROVED",
            "APPROVED_WITH_OBLIGATIONS",
        }:
            raise ValueError("Archivo sin revisión de derechos en SBOM")
    if any(
        row.get("licenseConcluded") in {None, "NOASSERTION"} for row in spdx["files"]
    ):
        raise ValueError("Licencia de un archivo sin concluir en SPDX")
    if not artifact.get("notice_members") or any(
        name not in expected for name in artifact["notice_members"]
    ):
        raise ValueError("Avisos no incluidos dentro del paquete final")


def verify_deployment(manifest: dict) -> None:
    """Vincula el compose efectivo y cada imagen inmutable sin exponer sus variables."""
    plan = manifest.get("deployment", {})
    result = subprocess.run(
        ["docker", "compose", "config", "--format", "json"],
        capture_output=True,
        timeout=30,
        check=True,
    )
    config = json.loads(result.stdout)
    canonical = json.dumps(config, sort_keys=True, separators=(",", ":")).encode()
    if hashlib.sha256(canonical).hexdigest() != plan.get("compose_config_sha256"):
        raise ValueError("Configuración de despliegue distinta de la aprobada")
    services = config["services"]
    if set(plan.get("images", {})) != set(services):
        raise ValueError("Plan no cubre todas las imágenes del despliegue")
    reviewed_images = {row.get("image_ref") for row in manifest.get("artifacts", [])}
    if not set(plan["images"].values()).issubset(reviewed_images):
        raise ValueError("Imagen sin paquete final revisado y vinculado al manifiesto")
    for service, definition in services.items():
        image = definition.get("image", "")
        if (
            not re.fullmatch(r"[^\s@]+@sha256:[0-9a-f]{64}", image)
            or image != plan["images"][service]
        ):
            raise ValueError("Imagen mutable o distinta de la aprobada")
        subprocess.run(
            ["docker", "image", "inspect", image],
            capture_output=True,
            timeout=15,
            check=True,
        )


def verify(
    root: Path, manifest: dict, trust: dict, policy: dict, deployment=False
) -> dict:
    if (
        policy.get("approved") is not True
        or policy.get("status") != "APPROVED"
        or policy.get("blockers")
    ):
        raise ValueError("RELEASE_BLOCKED: política comercial conserva bloqueos")
    if (
        manifest.get("schema_version") != 1
        or manifest.get("status") != "RELEASE_READY"
        or manifest.get("purpose") != "commercial"
    ):
        raise ValueError("Manifiesto comercial no aprobado")
    expires = datetime.fromisoformat(manifest["expires_at"].replace("Z", "+00:00"))
    if expires.tzinfo is None or expires <= datetime.now(timezone.utc):
        raise ValueError("Aprobación vencida o sin zona UTC")
    verify_signatures(root, manifest, trust)
    findings = manifest.get("findings", [])
    if {row.get("id") for row in findings} != {
        "LIC-" + str(i).zfill(2) for i in range(1, 14)
    } or len(findings) != 13:
        raise ValueError("Faltan hallazgos originales")
    for row in findings:
        if (
            row.get("status") not in RESOLVED
            or row.get("obligations_completed") is not True
        ):
            raise ValueError("Hallazgo abierto: " + row["id"])
        evidence(root, row["evidence"])
    for group, required in (("rights", RIGHTS), ("checks", CHECKS)):
        if set(manifest.get(group, {})) != required:
            raise ValueError("Cobertura incompleta: " + group)
        for row in manifest[group].values():
            if row.get("status") != "PASS":
                raise ValueError("Validación pendiente: " + group)
            evidence(root, row["evidence"])
    if not manifest.get("inputs") or not manifest.get("artifacts"):
        raise ValueError("Entradas o paquetes finales ausentes")
    for row in manifest["inputs"]:
        evidence(root, row)
    for artifact in manifest["artifacts"]:
        verify_artifact(root, artifact)
    if deployment:
        verify_deployment(manifest)
    return {
        "status": "RELEASE_READY",
        "artifacts_verified": len(manifest["artifacts"]),
        "publication_performed": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parent.parent
    )
    parser.add_argument(
        "--manifest", default="docs/compliance/closure/release-candidate.json"
    )
    parser.add_argument("--trust", default="docs/compliance/closure/release-trust.json")
    parser.add_argument("--policy", default="docs/compliance/commercial-release.json")
    parser.add_argument("--deployment", action="store_true")
    args = parser.parse_args()
    try:
        policy = json.loads(confined(args.root, args.policy).read_text())
        if (
            policy.get("approved") is not True
            or policy.get("status") != "APPROVED"
            or policy.get("blockers")
        ):
            raise ValueError(
                "RELEASE_BLOCKED: derechos y aprobaciones comerciales pendientes"
            )
        manifest = json.loads(confined(args.root, args.manifest).read_text())
        trust = json.loads(confined(args.root, args.trust).read_text())
        print(json.dumps(verify(args.root, manifest, trust, policy, args.deployment)))
        return 0
    except (
        ValueError,
        KeyError,
        TypeError,
        OSError,
        subprocess.SubprocessError,
        StopIteration,
    ) as error:
        print(
            json.dumps(
                {
                    "status": "RELEASE_BLOCKED",
                    "reason": str(error),
                    "publication_performed": False,
                }
            )
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
