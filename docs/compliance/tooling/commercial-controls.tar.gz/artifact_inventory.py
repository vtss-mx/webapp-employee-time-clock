#!/usr/bin/env python3
"""Huella de archivos de un paquete final, sin extraer ni ejecutar su contenido.

Los archivos desconocidos permanecen NOASSERTION; enumerarlos no acredita licencia.
Se rechazan enlaces, rutas ambiguas y secretos antes de producir evidencia.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import tarfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def safe_name(name: str) -> str:
    parts = PurePosixPath(name).parts
    if not parts or name.startswith("/") or ".." in parts or "\\" in name:
        raise ValueError("Ruta insegura en artefacto")
    if any(
        p.startswith(".env") or p == ".git" or p.endswith((".key", ".p12", ".pfx"))
        for p in parts
    ):
        raise ValueError("Artefacto contiene una ruta de secretos o historial Git")
    return str(PurePosixPath(name))


def archive_files(path: Path) -> list:
    result = {}
    total = 0

    def add(name, size, stream):
        nonlocal total
        name = safe_name(name)
        total += size
        if name in result or total > 2147483648 or len(result) >= 100000:
            raise ValueError("Contenido duplicado o límite de archivo excedido")
        value = hashlib.sha256()
        actual = 0
        with stream:
            for block in iter(lambda: stream.read(1048576), b""):
                actual += len(block)
                if actual > size:
                    raise ValueError("Tamaño del miembro inconsistente")
                value.update(block)
        if actual != size:
            raise ValueError("Miembro truncado")
        result[name] = {"path": name, "sha256": value.hexdigest(), "size_bytes": size}

    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            for member in archive.infolist():
                if member.is_dir():
                    continue
                if ((member.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError("Enlace en artefacto")
                add(member.filename, member.file_size, archive.open(member))
    else:
        with tarfile.open(path, "r:*") as archive:
            for member in archive:
                if member.isdir():
                    continue
                if not member.isfile():
                    raise ValueError("Miembro no regular en artefacto")
                add(member.name, member.size, archive.extractfile(member))
    if not result:
        raise ValueError("Artefacto vacío")
    return [result[name] for name in sorted(result)]


def boms(path: Path, name: str) -> tuple:
    checksum = digest(path)
    rows = archive_files(path)
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    cdx = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "version": 1,
        "metadata": {
            "timestamp": stamp,
            "component": {
                "type": "application",
                "bom-ref": "artifact",
                "name": name,
                "version": checksum[:16],
                "hashes": [{"alg": "SHA-256", "content": checksum}],
            },
        },
        "components": [
            {
                "type": "file",
                "bom-ref": "file-" + str(i),
                "name": row["path"],
                "hashes": [{"alg": "SHA-256", "content": row["sha256"]}],
                "properties": [{"name": "ivp:status", "value": "LICENSE_NOT_VERIFIED"}],
            }
            for i, row in enumerate(rows)
        ],
    }
    spdx = {
        "spdxVersion": "SPDX-2.3",
        "dataLicense": "CC0-1.0",
        "SPDXID": "SPDXRef-DOCUMENT",
        "name": name,
        "documentNamespace": "https://vtss.invalid/artifact/" + checksum,
        "creationInfo": {"created": stamp, "creators": ["Tool: artifact_inventory.py"]},
        "packages": [
            {
                "SPDXID": "SPDXRef-artifact",
                "name": name,
                "downloadLocation": "NOASSERTION",
                "filesAnalyzed": False,
                "licenseDeclared": "NOASSERTION",
                "licenseConcluded": "NOASSERTION",
                "copyrightText": "NOASSERTION",
                "checksums": [{"algorithm": "SHA256", "checksumValue": checksum}],
            }
        ],
        "files": [
            {
                "SPDXID": "SPDXRef-file-" + str(i),
                "fileName": row["path"],
                "checksums": [{"algorithm": "SHA256", "checksumValue": row["sha256"]}],
                "licenseConcluded": "NOASSERTION",
                "licenseInfoInFiles": ["NOASSERTION"],
                "copyrightText": "NOASSERTION",
            }
            for i, row in enumerate(rows)
        ],
        "relationships": [
            {
                "spdxElementId": "SPDXRef-DOCUMENT",
                "relatedSpdxElement": "SPDXRef-artifact",
                "relationshipType": "DESCRIBES",
            }
        ]
        + [
            {
                "spdxElementId": "SPDXRef-artifact",
                "relatedSpdxElement": "SPDXRef-file-" + str(i),
                "relationshipType": "CONTAINS",
            }
            for i in range(len(rows))
        ],
    }
    descriptor = {
        "name": name,
        "sha256": checksum,
        "size_mb": round(path.stat().st_size / 1048576, 2),
        "files": rows,
        "legal_status": "TECHNICAL_VALIDATION_PENDING",
        "scope": "Paquete final de prueba; no grafo de dependencias resuelto ni aprobación jurídica",
    }
    return descriptor, cdx, spdx


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", args.name):
        parser.error("El nombre del artefacto debe ser un identificador sin ruta")
    descriptor, cdx, spdx = boms(args.artifact, args.name)
    args.output.mkdir(parents=True, exist_ok=True)
    for suffix, value in (("inventory", descriptor), ("cdx", cdx), ("spdx", spdx)):
        (args.output / (args.name + "." + suffix + ".json")).write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    print(
        json.dumps(
            {
                "artifact": args.name,
                "sha256": descriptor["sha256"],
                "files": len(descriptor["files"]),
                "commercial_approval": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
